#!/usr/bin/env bash
# Build a single tarball you can scp to the server. Run from the backend/ directory:
#   ./server-seed-ssh-bundle/PACK.sh
set -euo pipefail

BACKEND="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUNDLE="$BACKEND/server-seed-ssh-bundle"
OUT="$BUNDLE/aurestra-seed-ssh.tgz"

cp -f "$BACKEND/db/seed_from_sqlite_backup.py" "$BUNDLE/seed_from_sqlite_backup.py"

tar -czf "$OUT" \
  -C "$BACKEND" \
  server-seed-ssh-bundle/README.md \
  server-seed-ssh-bundle/run_seed.sh \
  server-seed-ssh-bundle/PACK.sh \
  server-seed-ssh-bundle/backups/.gitkeep \
  server-seed-ssh-bundle/seed_from_sqlite_backup.py

echo "Created: $OUT"
echo "Copy backup DB into backups/ on the server, or scp it separately."
