# Server DB seed (SSH bundle)

Use this folder to **copy a backup `aurestra.db` into the live SQLite file** on your server (merge / upsert behaviour; safe to re-run for most tables).

## What to send over SSH

**Option A — one archive (recommended)**  
On your dev machine, from the `backend/` directory:

```bash
chmod +x server-seed-ssh-bundle/PACK.sh server-seed-ssh-bundle/run_seed.sh
./server-seed-ssh-bundle/PACK.sh
```

That creates `server-seed-ssh-bundle/aurestra-seed-ssh.tgz` containing this README, `run_seed.sh`, `PACK.sh`, `backups/.gitkeep`, and `seed_from_sqlite_backup.py`.

Upload it:

```bash
scp server-seed-ssh-bundle/aurestra-seed-ssh.tgz user@your-server:/tmp/
```

**Option B — folder only**  
From `backend/`:

```bash
scp -r server-seed-ssh-bundle user@your-server:/path/to/your/app/backend/
```

Also copy your backup SQLite file to `server-seed-ssh-bundle/backups/aurestra.db` on the server (or upload it with a second `scp`).

## Layout on the server

Unpack the tarball **inside** your deployed `backend/` tree so this folder sits next to `db/` and your real `aurestra.db`:

```text
backend/
  aurestra.db              ← live DB (target)
  db/
    ...
  server-seed-ssh-bundle/
    README.md
    run_seed.sh
    seed_from_sqlite_backup.py
    backups/
      aurestra.db          ← put your backup here (source)
```

If your layout differs, use environment variables (below) instead of defaults.

## Before you run anything

1. **Stop** the Flask / gunicorn process that uses `aurestra.db` (or accept a small risk of SQLITE_BUSY).
2. **Back up** the current live DB:

   ```bash
   cp /path/to/backend/aurestra.db /path/to/backend/aurestra.db.bak.$(date +%Y%m%d%H%M)
   ```

## Run the seeder

**Dry run** (prints SQL plan, no writes):

```bash
cd /path/to/backend/server-seed-ssh-bundle
chmod +x run_seed.sh
./run_seed.sh --dry-run
```

**Apply** merge from `backups/aurestra.db` into `../aurestra.db`:

```bash
./run_seed.sh
```

Defaults:

- Source: `backups/aurestra.db` (override with `SEED_SOURCE`)
- Target: `../aurestra.db` when this folder is inside `backend/` (override with `SEED_TARGET` or `AURESTRA_BACKEND`)

**Custom paths:**

```bash
export SEED_SOURCE=/tmp/my-backup.db
export SEED_TARGET=/var/www/aurestra/backend/aurestra.db
./run_seed.sh
```

Or call Python directly:

```bash
python3 /path/to/backend/server-seed-ssh-bundle/seed_from_sqlite_backup.py \
  --source /path/to/backup.db \
  --target /path/to/live/aurestra.db
```

## Refresh the script from git

The canonical copy lives at `backend/db/seed_from_sqlite_backup.py`. After `git pull`, either re-run `PACK.sh` or:

```bash
cp db/seed_from_sqlite_backup.py server-seed-ssh-bundle/seed_from_sqlite_backup.py
```

## Notes

- This is **not** the same as `python3 db/setup.py`: setup skips seed SQL when tables already have rows. Use this importer when you want to load a **snapshot** into an existing DB.
- Requires **Python 3** with the standard library only (uses `sqlite3`).
